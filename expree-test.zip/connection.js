import mongoose from "mongoose";
import { config } from "dotenv"
config()
const mode = process.env.MODE == 'production'? "stepDB" : "testDB"
export async function createConnection(){
    await mongoose.connect(`mongodb://127.0.0.1:27017/${mode}`);
    return mongoose
}

