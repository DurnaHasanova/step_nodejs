request(server)
    .get("/product")