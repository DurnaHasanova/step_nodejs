import request from 'supertest';
import {server} from '../server.js'
import { describe } from 'mocha';
import assert from 'assert'
import { User } from '../entities/user.entity.js';
import { createToken } from '../authorization/crypt.js';
let TOKEN = ''
describe("Products", () => {
    before(async() => {
        const check_user = await User.findOne({username: "mahmud"})
        if(!check_user){
            const user = await User.create({username:"mahmud", "email": "fatullayevm@gmail.com", 'password': "qwerty12345"})
            const token = createToken(user.toJSON())
            TOKEN = token
        }else {
            const token = createToken(check_user.toJSON())
            TOKEN = token
        }
    })
    it('Check get products', function (done) {
        request(server)
        .get("/product")
        .set("Authorization", `Bearer ${TOKEN}`)
        .expect(200, done)
      });
    it('Post new product', function(done){
        request(server)
        .post("/product")
        .set("Authorization", `Bearer ${TOKEN}`)
        .send({'name': "activePro"})
        .expect(200, done)
    })
})
