import { createConnection } from "../connection.js"

const mongoose = await createConnection()

const commentSchema = mongoose.Schema({
    blogID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Blog',
        required: true,
    },
    userID: { type: mongoose.Types.ObjectId, ref: "User" },
    text: {
        type: String,
        required: true,
    },
    rating: [{type: mongoose.Types.ObjectId, ref: "Rating"}]

}, {
    timestamps: true
});


export const Comment = mongoose.model('Comment', commentSchema);